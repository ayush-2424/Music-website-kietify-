<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Music login page </title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
<!--nav bar-->
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="vacation/stylesheet">

    <link rel="stylesheet" href="vacation/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="vacation/css/animate.css">
    
    <link rel="stylesheet" href="vacation/css/owl.carousel.min.css">
    <link rel="stylesheet" href="vacation/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="vacation/css/magnific-popup.css">

    <link rel="stylesheet" href="vacation/css/aos.css">

    <link rel="stylesheet" href="vacation/css/ionicons.min.css">

    <link rel="stylesheet" href="vacation/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="vacation/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="vacation/css/flaticon.css">
    <link rel="stylesheet" href="vacation/css/icomoon.css">
    <link rel="stylesheet" href="vacation/css/style.css">
</head>
<body>
     <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
          <h2 class="form-title"> &#9763;kietify<span> music sites</span></a></h2>
        
          <h2 class="form-title">Get great music, right now....</h2>

          

            </ul>
          </div>
        </div>


      </nav>
    <!-- END nav -->


    <div class="main">
    	  <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                        <a href="signup.php" class="signup-image-link">Create an account</a>
                    </div>

                    <div class="signin-form">
                     <!-- <h2 class="form-title">Please login for booking✈</h2> -->
                        <h2 class="form-title">Login pages</h2>
                        <form method="POST" class="register-form" id="login-form" action="check.php">
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name"/>
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="password" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="signin" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
